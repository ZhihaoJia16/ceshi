#This is a setup.py.


from distutils.core import setup
setup(name='PKG1',version='2.0',description='作业：发布包',author='Mr. Jia',py_module=['package1.module1','package2.module2'])